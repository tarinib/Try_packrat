library(testthat)
library(dbplot)

test_check("dbplot")
